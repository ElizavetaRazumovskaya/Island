import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.random.Random
import kotlin.system.exitProcess
import java.util.concurrent.ExecutorService

// ⚙️ Класс параметров симуляции


data class SimulationSettings(
    val islandWidth: Int = 20,
    val islandHeight: Int = 10,
    val simulationSpeed: Long = 1,
    val initialPlants: IntRange = 5..20,
    val plantGrowthRate: Int = 10,
    val verboseLogging: Boolean = false,
    val fullReportInterval: Int = 3,
    val stopCondition: (Island) -> Boolean = { false }
)


// 🌍 Остров
class Island(val settings: SimulationSettings) {
    val grid: Array<Array<Location>> = Array(settings.islandWidth) {
        Array(settings.islandHeight) { Location(settings.initialPlants.random()) }
    }

    private val animalStats = mutableMapOf<String, Int>()
    private var totalPlants = grid.sumOf { row -> row.sumOf { it.plants } }

    private fun updateStats() {
        animalStats.clear()
        for (row in grid) {
            for (cell in row) {
                cell.animals.groupBy { it::class.simpleName!! }.forEach { (name, animals) ->
                    animalStats[name] = (animalStats[name] ?: 0) + animals.size
                }
            }
        }
        totalPlants = grid.sumOf { row -> row.sumOf { it.plants } }
    }

    fun printFullReport(tick: Int) {
        updateStats()
        println("\n=== ⏳ ТАКТ $tick ===")
        printIslandMap()
        printStatistics()
    }

    private fun printIslandMap() {
        println("\n🏝️ КАРТА ОСТРОВА:")
        for (y in 0 until grid[0].size) {
            for (x in 0 until grid.size) {
                val cell = grid[x][y]
                when {
                    cell.animals.isEmpty() -> print("[🌿]")  // Пустые клетки как растения
                    cell.animals.size == 1 -> print("[${cell.animals[0].emoji}]")
                    cell.animals.size == 2 -> {
                        val emojis = cell.animals.take(2).joinToString("") { it.emoji }
                        print("[$emojis]")
                    }
                    else -> {
                        // Для 3+ животных показываем иконку доминирующего вида
                        val dominant = cell.animals.groupBy { it::class }
                            .maxByOrNull { it.value.size }?.value?.first()
                        print("[${dominant?.emoji ?: "•"}${cell.animals.size}]")
                    }
                }
            }
            println()
        }
    }

    fun printStatistics() {
        updateStats()
        println("\n📊 СТАТИСТИКА:")
        println("🌿 Всего растений: $totalPlants")
        println("🦌 Всего животных: ${animalStats.values.sum()}")

        // Сортируем по убыванию и выводим только топ-15 видов
        animalStats.toList()
            .sortedByDescending { (_, count) -> count }
            .take(15)
            .forEach { (name, count) ->
                println("$name: $count")
            }
    }

    fun growPlants() {
        for (row in grid) {
            for (cell in row) {
                // Логистический рост - быстрее при малом количестве
                val growthFactor = when {
                    cell.plants < 5 -> 3.0
                    cell.plants < 10 -> 2.0
                    cell.plants < 20 -> 1.5
                    else -> 1.0
                }
                val newPlants = cell.plants + (settings.plantGrowthRate * growthFactor).toInt()
                cell.plants = newPlants.coerceAtMost(50)  // Максимум 50 растений в клетке
            }
        }
    }
}

// 📍 Клетка острова
class Location(var plants: Int = 0) {
    val animals = mutableListOf<Animal>()

    fun canAddAnimal(maxPerCell: Int): Boolean {
        // Учитываем общее количество животных в клетке
        val totalAnimals = animals.size
        return totalAnimals < maxPerCell * 0.8 // 80% от максимума
    }
}

// 🦁 Базовый класс животного
abstract class Animal(
    val weight: Double,
    val maxPerCell: Int,
    val speed: Int,
    val foodNeed: Double,
    val emoji: String
) {
    var satiety: Double = foodNeed * 0.5
    var isAlive: Boolean = true
    lateinit var island: Island
    open val reproductionProbability: Double = 0.25
    open val reproductionThreshold: Int = 3
    open val reproductionFoodRequirement: Double = 0.5

    abstract fun move(island: Island, x: Int, y: Int)
    abstract fun eat(location: Location)
    abstract fun reproduce(location: Location)

    fun decreaseSatiety() {
        satiety -= foodNeed * 0.1
        if (satiety <= 0) {
            isAlive = false
            println("$emoji погиб от голода! ☠️")
        }
    }

    protected fun tryMove(island: Island, x: Int, y: Int, maxSteps: Int = 1) {
        repeat(Random.nextInt(1, maxSteps + 1)) {
            val dx = listOf(-1, 0, 1).random()
            val dy = listOf(-1, 0, 1).random()
            val newX = (x + dx).coerceIn(0, island.grid.size - 1)
            val newY = (y + dy).coerceIn(0, island.grid[0].size - 1)

            if (island.grid[newX][newY].canAddAnimal(maxPerCell)) {
                island.grid[newX][newY].animals.add(this)
                island.grid[x][y].animals.remove(this)
                return
            }
        }
    }

    protected fun tryReproduce(location: Location, createAnimal: () -> Animal) {
        val sameSpecies = location.animals.filter { it::class == this::class }

        // Упрощенные условия:
        val enoughAnimals = sameSpecies.size >= reproductionThreshold
        val notOvercrowded = location.animals.size < maxPerCell
        val healthy = satiety > foodNeed * 0.5

        if (enoughAnimals && notOvercrowded && healthy) {
            val reproductionChance = reproductionProbability * (satiety / foodNeed)

            if (Random.nextDouble() < reproductionChance) {
                val baby = createAnimal()
                baby.island = this.island
                location.animals.add(baby)
                if (island.settings.verboseLogging) println("$emoji размножился! 👶")
            }
        }
    }
}

// 🦊 Хищники
abstract class Predator(
    weight: Double,
    maxPerCell: Int,
    speed: Int,
    foodNeed: Double,
    emoji: String,
    private val preyTable: Map<Class<out Animal>, Int>
) : Animal(weight, maxPerCell, speed, foodNeed, emoji) {
    override open val reproductionProbability: Double = 0.2
    override open val reproductionThreshold: Int = 2
    override open val reproductionFoodRequirement: Double = 0.4

    override fun eat(location: Location) {
        val potentialPrey = location.animals.filter { preyTable.containsKey(it::class.java) }
        potentialPrey.forEach { prey ->
            val probability = preyTable[prey::class.java]!!
            if (Random.nextInt(100) < probability) {
                location.animals.remove(prey)
                satiety += prey.weight * 0.7
                println("$emoji съел ${prey.emoji} (${prey::class.simpleName})!")
                return
            }
        }
    }
}

// 🦌 Травоядные
abstract class Herbivore(
    weight: Double,
    maxPerCell: Int,
    speed: Int,
    foodNeed: Double,
    emoji: String

) : Animal(weight, maxPerCell, speed, foodNeed, emoji) {

    override fun eat(location: Location) {
        val plantsToEat = minOf(foodNeed, location.plants.toDouble())
        if (plantsToEat > 0) {
            location.plants -= plantsToEat.toInt()
            satiety += plantsToEat
            // Форматируем вывод до 2 знаков после запятой
            if (island.settings.verboseLogging) {
                val formatted = "%.2f".format(plantsToEat)
                println("$emoji съел $formatted кг растений 🌿")
            }
        }
    }

}

// 🐺 Волк
class Wolf : Predator(
    weight = 50.0,
    maxPerCell = 30,
    speed = 3,
    foodNeed = 4.0,
    emoji = "🐺",
    preyTable = mapOf(
        Deer::class.java to 15,
        Rabbit::class.java to 60,
        Mouse::class.java to 80,
        Goat::class.java to 60,
        Sheep::class.java to 70,
        Duck::class.java to 40
    )
) {
    override val reproductionProbability = 0.7
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.2
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Wolf() }
}

// 🐍 Удав
class Boa : Predator(
    weight = 15.0,
    maxPerCell = 30,
    speed = 1,
    foodNeed = 0.8,
    emoji = "🐍",
    preyTable = mapOf(
        Fox::class.java to 15,
        Rabbit::class.java to 20,
        Mouse::class.java to 40,
        Duck::class.java to 10
    )
) {
    override val reproductionProbability = 0.8
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.01
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Boa() }
}

// 🦊 Лиса
class Fox : Predator(
    weight = 8.0,
    maxPerCell = 30,
    speed = 2,
    foodNeed = 2.0,
    emoji = "🦊",
    preyTable = mapOf(
        Rabbit::class.java to 70,
        Mouse::class.java to 90,
        Duck::class.java to 60,
        Caterpillar::class.java to 40
    )
) {
    override val reproductionProbability = 0.4
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.3
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Fox() }
}

// 🐻 Медведь
class Bear : Predator(
    weight = 500.0,
    maxPerCell = 5,
    speed = 2,
    foodNeed = 80.0,
    emoji = "🐻",
    preyTable = mapOf(
        Wolf::class.java to 80,
        Horse::class.java to 40,
        Deer::class.java to 80,
        Rabbit::class.java to 80,
        Mouse::class.java to 90,
        Goat::class.java to 70,
        Sheep::class.java to 70,
        Boar::class.java to 50,
        Duck::class.java to 10
    )
) {
    override val reproductionProbability = 0.2
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.5
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Bear() }
}

// 🦅 Орел
class Eagle : Predator(
    weight = 6.0,
    maxPerCell = 20,
    speed = 3,
    foodNeed = 1.0,
    emoji = "🦅",
    preyTable = mapOf(
        Fox::class.java to 10,
        Rabbit::class.java to 90,
        Mouse::class.java to 90,
        Duck::class.java to 80
    )
) {
    override val reproductionProbability = 0.9
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.1
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Eagle() }
}

// 🐎 Лошадь
class Horse : Herbivore(
    weight = 400.0,
    maxPerCell = 20,
    speed = 4,
    foodNeed = 60.0,
    emoji = "🐎"
) {
    override val reproductionProbability = 0.6
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.2
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Horse() }
}

// 🦌 Олень
class Deer : Herbivore(
    weight = 300.0,
    maxPerCell = 20,
    speed = 4,
    foodNeed = 50.0,
    emoji = "🦌"
) {
    override val reproductionProbability = 0.35
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.4
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Deer() }
}

// 🐇 Кролик
class Rabbit : Herbivore(
    weight = 2.0,
    maxPerCell = 20,
    speed = 2,
    foodNeed = 0.65,
    emoji = "🐇"

) {
    override val reproductionProbability = 0.001
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.99
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Rabbit() }
}

// 🐁 Мышь
class Mouse : Herbivore(
    weight = 0.05,
    maxPerCell = 60,
    speed = 1,
    foodNeed = 0.02,
    emoji = "🐁"
) {
    override val reproductionProbability = 0.8  // Было 0.7
    override val reproductionThreshold = 3      // Было 2
    override val reproductionFoodRequirement = 0.3  // Было 0.1
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Mouse() }
}

// 🐐 Коза
class Goat : Herbivore(
    weight = 60.0,
    maxPerCell = 20,
    speed = 3,
    foodNeed = 35.0,
    emoji = "🐐"
) {
    override val reproductionProbability = 0.001
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 45.0
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Goat() }
}

// 🐑 Овца
class Sheep : Herbivore(
    weight = 70.0,
    maxPerCell = 30,
    speed = 3,
    foodNeed = 15.0,
    emoji = "🐑"
) {
    override val reproductionProbability = 0.01
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 15.0
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Sheep() }
}

// 🐗 Кабан
class Boar : Herbivore(
    weight = 400.0,
    maxPerCell = 20,
    speed = 2,
    foodNeed = 50.0,
    emoji = "🐗"
) {
    override val reproductionProbability = 0.3
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.4
    override fun eat(location: Location) {
        val caterpillar = location.animals.filterIsInstance<Caterpillar>().randomOrNull()
        if (caterpillar != null && Random.nextInt(100) < 90) {
            location.animals.remove(caterpillar)
            satiety += caterpillar.weight * 0.7
            println("$emoji съел 🐛!")
        } else {
            super.eat(location)
        }
    }

    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Boar() }
}

// 🐃 Буйвол
class Buffalo : Herbivore(
    weight = 700.0,
    maxPerCell = 10,
    speed = 3,
    foodNeed = 100.0,
    emoji = "🐃"
) {
    override val reproductionProbability = 0.25
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.5
    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Buffalo() }
}

// 🦆 Утка
class Duck : Herbivore(
    weight = 1.0,
    maxPerCell = 20,
    speed = 4,
    foodNeed = 0.15,
    emoji = "🦆"
) {
    override val reproductionProbability = 0.01
    override val reproductionThreshold = 2
    override val reproductionFoodRequirement = 0.3
    override fun eat(location: Location) {
        val caterpillar = location.animals.filterIsInstance<Caterpillar>().randomOrNull()
        if (caterpillar != null && Random.nextInt(100) < 90) {
            location.animals.remove(caterpillar)
            satiety += caterpillar.weight * 0.7
            println("$emoji съел 🐛!")
        } else {
            super.eat(location)
        }
    }

    override fun move(island: Island, x: Int, y: Int) = tryMove(island, x, y, speed)
    override fun reproduce(location: Location) = tryReproduce(location) { Duck() }
}

// 🐛 Гусеница
class Caterpillar : Herbivore(
    weight = 0.01,
    maxPerCell = 300,
    speed = 0,
    foodNeed = 0.0,
    emoji = "🐛"
) {
    override fun move(island: Island, x: Int, y: Int) {} // Гусеницы не двигаются
    override fun reproduce(location: Location) {
        if (Random.nextDouble() < 0.5 && location.canAddAnimal(maxPerCell)) {
            location.animals.add(Caterpillar())
        }
    }
}

// 🚀 Симуляция
class Simulation(private val island: Island, private val settings: SimulationSettings) {
    private val scheduledExecutor: ScheduledExecutorService = Executors.newScheduledThreadPool(3)
    private val animalExecutor: ExecutorService = Executors.newFixedThreadPool(10)
    private var tickCount = 0

    fun start() {
        // Запускаем рост растений
        scheduledExecutor.scheduleAtFixedRate(
            { island.growPlants() },
            3, 3, TimeUnit.SECONDS
        )

        // Основной цикл симуляции
        scheduledExecutor.scheduleAtFixedRate(
            {
                if (tickCount % settings.fullReportInterval == 0 || settings.stopCondition(island)) {
                    island.printFullReport(tickCount)
                }

                if (settings.stopCondition(island)) {
                    println("\n=== ⏹️ СИМУЛЯЦИЯ ЗАВЕРШЕНА ===")
                    stop()
                    return@scheduleAtFixedRate
                }

                tick()
            },
            0, settings.simulationSpeed, TimeUnit.SECONDS
        )
    }

    private fun tick() {
        tickCount++

        if (settings.verboseLogging) {
            println("\n=== 🌀 Такт $tickCount ===")
        }

        // Обработка животных в одном потоке для стабильности
        for (x in island.grid.indices) {
            for (y in island.grid[x].indices) {
                val location = island.grid[x][y]
                location.animals.toList().forEach { animal ->
                    animal.move(island, x, y)
                    animal.eat(location)
                    animal.reproduce(location)
                    animal.decreaseSatiety()

                    if (!animal.isAlive) {
                        location.animals.remove(animal)
                    }
                }
            }
        }
    }
    fun stop() {
        try {
            // Даем время на завершение текущих задач
            scheduledExecutor.shutdown()
            animalExecutor.shutdown()

            if (!scheduledExecutor.awaitTermination(2, TimeUnit.SECONDS)) {
                scheduledExecutor.shutdownNow()
            }
            if (!animalExecutor.awaitTermination(2, TimeUnit.SECONDS)) {
                animalExecutor.shutdownNow()
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        // Выводим финальную статистику
        island.printFullReport(tickCount)
    }
}

// 🔥 Запуск симуляции
fun main() {
    // Сначала создаем island с базовыми настройками
    val settings = SimulationSettings(
        islandWidth = 15,
        islandHeight = 10,
        simulationSpeed = 1,
        initialPlants = 15..30,
        plantGrowthRate = 3,
        verboseLogging = true,
        fullReportInterval = 3
    )

    val island = Island(settings)

    // Инициализация животных
    fun addRandomAnimals(animalClass: () -> Animal, count: Int) {
        repeat(count) {
            val x = Random.nextInt(settings.islandWidth)
            val y = Random.nextInt(settings.islandHeight)
            if (island.grid[x][y].canAddAnimal(animalClass().maxPerCell)) {
                val animal = animalClass()
                animal.island = island  // Инициализируем ссылку на остров
                island.grid[x][y].animals.add(animal)
            }
        }
    }


    // Добавляем хищников
    addRandomAnimals(::Wolf, 5)
    addRandomAnimals(::Boa, 5)
    addRandomAnimals(::Fox, 8)
    addRandomAnimals(::Bear, 2)
    addRandomAnimals(::Eagle, 4)

    // Добавляем травоядных
    addRandomAnimals(::Horse, 5)
    addRandomAnimals(::Deer, 8)
    addRandomAnimals(::Rabbit, 15)
    addRandomAnimals(::Mouse, 20)
    addRandomAnimals(::Goat, 10)
    addRandomAnimals(::Sheep, 10)
    addRandomAnimals(::Boar, 6)
    addRandomAnimals(::Buffalo, 3)
    addRandomAnimals(::Duck, 12)
    addRandomAnimals(::Caterpillar, 30)

    val simulation = Simulation(island, settings)
    simulation.start()

    // Остановка по нажатию Enter
    readln()
    simulation.stop()
}

